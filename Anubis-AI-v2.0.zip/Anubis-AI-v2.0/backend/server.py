import os
from typing import List

from fastapi import FastAPI, HTTPException
from openai import OpenAI
from pydantic import BaseModel, Field

app = FastAPI(title="Anubis API", version="2.0.0")

api_key = os.getenv("XAI_API_KEY")
model = os.getenv("XAI_MODEL", "grok-4")
if not api_key:
    raise RuntimeError("Define XAI_API_KEY en el entorno del servidor.")

client = OpenAI(
    api_key=api_key,
    base_url="https://api.x.ai/v1",
)

SYSTEM_PROMPT = (
    "Eres Anubis, un asistente de IA avanzado, directo y preciso. "
    "Responde de forma útil, segura y técnicamente clara."
)


class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=12000)


class ChatResponse(BaseModel):
    engine: str
    response: str
    status: str


@app.get("/health")
def health():
    return {"engine": "ANUBIS", "version": "2.0.0", "status": "READY"}


@app.post("/chat", response_model=ChatResponse)
def chat(request: ChatRequest):
    try:
        result = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": request.message},
            ],
            temperature=0.7,
        )
        answer = result.choices[0].message.content or ""
        return ChatResponse(
            engine="ANUBIS",
            response=answer,
            status="SUCCESS",
        )
    except Exception:
        # Do not expose provider errors, credentials, or internal details.
        raise HTTPException(
            status_code=502,
            detail="El motor de IA no pudo completar la consulta.",
        )
