# Anubis AI v2.0 — Flutter + xAI backend

Starter project containing a Flutter chat client and a Python/FastAPI backend
that calls the xAI API using the OpenAI-compatible SDK.

## Requirements

- Flutter SDK installed and configured.
- Python 3.10+ for the backend.
- An xAI API key.
- A deployed HTTPS URL for the backend when using a physical Android device.

## 1. Configure the Flutter app

Open `lib/app.dart` and replace:

`https://YOUR-ANUBIS-SERVER.example.com`

with the HTTPS base URL of your deployed backend. Do not put the xAI API key
in Flutter, in the APK, or in this repository.

Then run from this project directory:

```bash
flutter pub get
flutter build apk --release
```

Expected APK path:

`build/app/outputs/flutter-apk/app-release.apk`

## 2. Run the backend

From the `backend` directory:

```bash
python -m venv .venv
# Linux/macOS:
source .venv/bin/activate
# Windows PowerShell:
# .venv\\Scripts\\Activate.ps1

pip install -r requirements.txt
export XAI_API_KEY="YOUR_XAI_API_KEY"
export XAI_MODEL="grok-4"
uvicorn server:app --host 0.0.0.0 --port 8000
```

On Windows PowerShell, set variables with `$env:XAI_API_KEY="..."` and
`$env:XAI_MODEL="grok-4"`.

Check `GET /health` and send `POST /chat` with JSON `{"message":"Hola"}`.
Deploy behind HTTPS before connecting a public Android app.

## Included functionality

- Dark chat UI with user and assistant message bubbles.
- POST `/chat` integration and API health check.
- Basic request validation and user-facing network error handling.
- xAI key stays on the backend.

## Important limitations

- This is source code, not a prebuilt APK. The APK is created only after a
  successful Flutter build in an environment with Flutter and Android SDK.
- The sample backend handles each request independently; it does not yet
  persist conversation history or provide token streaming.
- Confirm the model identifier enabled for your xAI account and set
  `XAI_MODEL` accordingly.
- Add authentication, rate limiting, logging controls, and production
  deployment hardening before exposing the API publicly.
